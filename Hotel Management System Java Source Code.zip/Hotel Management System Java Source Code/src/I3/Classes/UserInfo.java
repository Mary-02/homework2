package I3.Classes;

/**
 * Represents user information with essential details such as customer ID, name, address, phone number, and type.
 * This class provides getters, setters, and a constructor to manage the user data.
 * 
 * @author maria
 */
public class UserInfo {

    // USER PROPERTIES
    private int customerId;
    private String name;
    private String address;
    private String phoneNo;
    private String type;

    // Constructor
    public UserInfo(int customerId, String name, String address, String phoneNo, String type) {
        this.customerId = customerId;
        this.name = name;
        this.address = address;
        this.phoneNo = phoneNo;
        this.type = type;
    }

    // Getter and Setter methods

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        if (isValidPhoneNumber(phoneNo)) {
            this.phoneNo = phoneNo;
        } else {
            System.out.println("Invalid phone number format.");
        }
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    // Input validation for phone number (basic check)
    private boolean isValidPhoneNumber(String phoneNo) {
        return phoneNo != null && phoneNo.matches("\\d{10}");
    }

    // Override toString method for better object representation
    @Override
    public String toString() {
        return "UserInfo{" +
                "customerId=" + customerId +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", phoneNo='" + phoneNo + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
