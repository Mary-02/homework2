package I3.Classes;

/**
 * Represents an order with details such as booking ID, food item, price, quantity, and total.
 *
 * @author maria
 */
public class Order {

    // Attributes
    private int orderId; // Unique ID for the order
    private int bookingId; // Associated booking ID
    private String foodItem; // Food item name
    private int price; // Price of the food item
    private int quantity; // Quantity ordered
    private int total; // Total cost of the order

    // Constructor
    public Order(int bookingId, String foodItem, int price, int quantity, int total) {
        this.bookingId = bookingId;
        this.foodItem = foodItem;
        this.price = price;
        this.quantity = quantity;
        this.total = total;
    }

    // Getters and Setters

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public String getFoodItem() {
        return foodItem;
    }

    public void setFoodItem(String foodItem) {
        this.foodItem = foodItem;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    // Additional Methods

    /**
     * Calculates and updates the total cost of the order based on price and quantity.
     */
    public void calculateTotal() {
        this.total = this.price * this.quantity;
    }
}
