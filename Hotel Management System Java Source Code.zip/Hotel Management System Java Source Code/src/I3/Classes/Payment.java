package I3.Classes;

import java.util.ArrayList;

/**
 * Represents a payment made for a booking, including additional orders and discounts.
 *
 * @author maria
 */
public class Payment {

    // Attributes
    private Booking booking; // Associated booking
    private ArrayList<ExtraOrders> orders; // List of additional orders
    private int totalRentPrice; // Total rent price for the stay
    private int daysStayed; // Number of days stayed
    private String paymentDate; // Date of payment
    private String paymentMethod; // Method of payment
    private boolean hasDiscount; // Indicates if a discount applies
    private float discount; // Discount percentage
    private int totalBill; // Total bill amount

    // Constructor
    public Payment(Booking booking) {
        this.booking = booking;
        this.orders = new ArrayList<>();
    }

    // Getters and Setters

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public ArrayList<ExtraOrders> getOrders() {
        return orders;
    }

    public void setOrders(ArrayList<ExtraOrders> orders) {
        this.orders = orders;
    }

    public int getTotalRentPrice() {
        return totalRentPrice;
    }

    public void setTotalRentPrice(int totalRentPrice) {
        this.totalRentPrice = totalRentPrice;
    }

    public int getDaysStayed() {
        return daysStayed;
    }

    public void setDaysStayed(int daysStayed) {
        this.daysStayed = daysStayed;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public boolean isHasDiscount() {
        return hasDiscount;
    }

    public void setHasDiscount(boolean hasDiscount) {
        this.hasDiscount = hasDiscount;
    }

    public float getDiscount() {
        return discount;
    }

    public void setDiscount(float discount) {
        this.discount = discount;
    }

    public int getTotalBill() {
        return totalBill;
    }

    // Methods

    /**
     * Calculates the total bill, including room rent, extra orders, and any discounts.
     *
     * @return Total bill amount.
     */
    public int calculateTotalBill() {
        int orderTotal = 0;

        for (ExtraOrders order : orders) {
            orderTotal += order.getQuantity() * order.getItem().getPrice();
        }

        totalBill = totalRentPrice + orderTotal;

        if (hasDiscount) {
            totalBill -= totalBill * (discount / 100);
        }

        return totalBill;
    }
}
