package I3.Classes;

import java.util.ArrayList;

/**
 * Represents a booking for a customer with associated rooms and details.
 *
 * @author maria
 */
public class Booking {

    // Attributes
    private UserInfo customer; // Customer associated with the booking
    private ArrayList<Room> rooms; // List of rooms in the booking
    private int bookingId; // Unique ID for the booking
    private long checkInDateTime; // Check-in date and time in milliseconds
    private long checkOutDateTime; // Check-out date and time in milliseconds
    private String bookingType; // Type of booking (e.g., "Reserved" or "Confirmed")
    private int numberOfPersons; // Number of persons for the booking

    // Constructor
    public Booking() {
        this.customer = new UserInfo();
        this.rooms = new ArrayList<>();
        this.bookingId = -1; // Default ID for uninitialized bookings
        this.bookingType = "Reserved"; // Default booking type
    }

    // Getters and Setters
    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public String getBookingType() {
        return bookingType;
    }

    public void setBookingType(String bookingType) {
        this.bookingType = bookingType;
    }

    public UserInfo getCustomer() {
        return customer;
    }

    public void setCustomer(UserInfo customer) {
        this.customer = customer;
    }

    public ArrayList<Room> getRooms() {
        return rooms;
    }

    public long getCheckInDateTime() {
        return checkInDateTime;
    }

    public void setCheckInDateTime(long checkInDateTime) {
        this.checkInDateTime = checkInDateTime;
    }

    public long getCheckOutDateTime() {
        return checkOutDateTime;
    }

    public void setCheckOutDateTime(long checkOutDateTime) {
        this.checkOutDateTime = checkOutDateTime;
    }

    public int getNumberOfPersons() {
        return numberOfPersons;
    }

    public void setNumberOfPersons(int numberOfPersons) {
        this.numberOfPersons = numberOfPersons;
    }

    // Methods

    /**
     * Adds a room to the booking by its room number.
     *
     * @param roomNo the room number to add
     */
    public void addRoom(String roomNo) {
        rooms.add(new Room(roomNo));
    }

    /**
     * Removes a room from the booking by its room number.
     *
     * @param roomNo the room number to remove
     */
    public void removeRoom(String roomNo) {
        rooms.removeIf(room -> room.getRoom_no().equals(roomNo));
    }

    /**
     * Calculates the total fare for all rooms in the booking.
     *
     * @return the total fare
     */
    public int calculateTotalRoomsFare() {
        return rooms.stream()
                    .mapToInt(room -> room.getRoom_class().getPricePerDay())
                    .sum();
    }
}