package I3.Classes;

/**
 * Represents the pricing details of a room based on its type.
 *
 * @author maria
 */
public class RoomFare {

    private String roomType; // Type of the room (e.g., Single, Double, Suite)
    private int pricePerDay; // Price of the room per day

    // Getter and Setter for roomType
    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    // Getter and Setter for pricePerDay
    public int getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(int pricePerDay) {
        this.pricePerDay = pricePerDay;
    }
}
