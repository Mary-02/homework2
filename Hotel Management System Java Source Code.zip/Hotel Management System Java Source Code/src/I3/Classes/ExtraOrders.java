package I3.Classes;

/**
 * Represents extra orders placed by a customer.
 *
 * @author maria
 */
public class ExtraOrders {

    // Attributes
    private int orderId; // Unique ID for the order
    private int customerId; // ID of the customer who placed the order
    private String dateTime; // Date and time of the order
    private int quantity; // Quantity of the item ordered
    private Item item; // Item associated with the order

    // Getters and Setters

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    /**
     * Calculates the total cost of the order based on the item price and quantity.
     *
     * @return the total cost of the order
     */
    public int calculateTotal() {
        return item.getPrice() * quantity;
    }
}