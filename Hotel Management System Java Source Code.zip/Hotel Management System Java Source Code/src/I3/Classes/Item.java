package I3.Classes;

/**
 * Represents an item with details such as ID, name, description, and price.
 *
 * @author maria
 */
public class Item {

    // Attributes
    private int itemId; // Unique ID for the item
    private String itemName; // Name of the item
    private String description; // Description of the item
    private int price; // Price of the item

    // Getters and Setters

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}