package I3.Classes;

/**
 * Represents a room with various attributes and facilities.
 *
 * @author maria
 */
public class Room {
    private int roomId; // Unique identifier for the room
    private String roomNo; // Room number
    private int bedNumber; // Number of beds in the room

    private boolean hasTV; // Indicates if the room has a TV
    private boolean hasWIFI; // Indicates if the room has Wi-Fi
    private boolean hasGeyser; // Indicates if the room has a geyser
    private boolean hasPhone; // Indicates if the room has a phone

    private RoomFare roomClass; // Class of the room and its fare

    // Constructor
    public Room(String roomNo) {
        this.roomNo = roomNo;
    }

    // Getters and Setters

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public String getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(String roomNo) {
        this.roomNo = roomNo;
    }

    public int getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(int bedNumber) {
        this.bedNumber = bedNumber;
    }

    public boolean isHasTV() {
        return hasTV;
    }

    public void setHasTV(boolean hasTV) {
        this.hasTV = hasTV;
    }

    public boolean isHasWIFI() {
        return hasWIFI;
    }

    public void setHasWIFI(boolean hasWIFI) {
        this.hasWIFI = hasWIFI;
    }

    public boolean isHasGeyser() {
        return hasGeyser;
    }

    public void setHasGeyser(boolean hasGeyser) {
        this.hasGeyser = hasGeyser;
    }

    public boolean isHasPhone() {
        return hasPhone;
    }

    public void setHasPhone(boolean hasPhone) {
        this.hasPhone = hasPhone;
    }

    public RoomFare getRoomClass() {
        return roomClass;
    }

    public void setRoomClass(RoomFare roomClass) {
        this.roomClass = roomClass;
    }
}
