package I3.Classes;

/**
 * Represents a food item with details such as ID, name, and price.
 *
 * @author maria
 */
public class Food {

    // Attributes
    private int foodId; // Unique ID for the food item
    private String name; // Name of the food item
    private int price; // Price of the food item

    // Getters and Setters

    public int getFoodId() {
        return foodId;
    }

    public void setFoodId(int foodId) {
        this.foodId = foodId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
